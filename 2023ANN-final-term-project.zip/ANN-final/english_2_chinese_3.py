import nltk
from nltk import data
import string
from gensim.models import Word2Vec
import re
import jieba
import collections
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import optim
import random, os
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def remove_punctuation(input_string):
    # 创建字符映射表，用于指定哪些字符需要被删除
    translator = str.maketrans('', '', string.punctuation)
    # 使用 translate() 方法传递该字符映射表，以在字符串中去除指定字符
    no_punct = input_string.translate(translator)
    return no_punct  # 返回去掉标点符号的string


num_layers = 3
epoch_num = 30
teacher_forcing_ratio = 0.5  # 设置 teacher forcing的一个随机值，即如果大于这个值，则decoder_input使用上一个时刻的预测值，否则使用对应的真实值


class EncoderRNN(nn.Module):  # 编码器模型
    def __init__(self, hidden_size):
        super(EncoderRNN, self).__init__()
        self.hidden_size = hidden_size
        self.gru = nn.GRU(hidden_size, hidden_size, num_layers)  # 设置gru为3层

    def forward(self, input, hidden):
        input = input.to(device)
        output, hidden = self.gru(input, hidden)
        return output, hidden

    def initHidden(self):
        return torch.zeros(num_layers, 1, self.hidden_size, device=device)  # 初始化h，即隐藏状态


class AttnDecoderRNN(nn.Module):  # 解码器模型
    def __init__(self, hidden_size, output_size, vector_len, dropout_p=0.1):
        super(AttnDecoderRNN, self).__init__()
        max_length = vector_len
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.dropout_p = dropout_p
        self.max_length = max_length
        # 将解码器隐藏状态维度调整为hidden_size
        self.fc_hidden = nn.Linear(self.hidden_size, self.hidden_size, bias=False)
        # 将编码器隐藏状态维度调整为hidden_size
        self.fc_encoder = nn.Linear(self.hidden_size, self.hidden_size, bias=False)
        # 对齐向量，用于计算注意力权重的向量
        self.alignment_vector = nn.Parameter(torch.Tensor(1, self.hidden_size))
        torch.nn.init.xavier_uniform_(self.alignment_vector)
        # 注意力全连接层，训练权重的分配
        self.attn = nn.Linear(self.hidden_size * 2, self.max_length)
        # 合并解码器和编码器的隐藏状态，生成注意力上下文向量
        self.attn_combine = nn.Linear(self.hidden_size * 2, self.hidden_size)
        self.dropout = nn.Dropout(self.dropout_p)
        self.gru = nn.GRU(self.hidden_size, self.hidden_size, num_layers)
        self.out = nn.Linear(self.hidden_size, self.output_size)

    def forward(self, input, hidden, encoder_outputs):
        input = input.to(device)
        embedded = self.dropout(input)

        transformed_hidden = self.fc_hidden(hidden[0])
        expanded_hidden_state = transformed_hidden.expand(self.max_length, -1)
        # 进行对齐，计算输入单词与生成单词之间的匹配度从而推算出注意力得分
        alignment_scores = torch.tanh(expanded_hidden_state +
                                      self.fc_encoder(encoder_outputs))
        alignment_scores = self.alignment_vector.mm(alignment_scores.T)
        # 因为注意力加权和为1所以使用softmax函数
        attn_weights = F.softmax(
            self.attn(torch.cat((embedded[0], hidden[0]), 1)), dim=1)
        attn_applied = torch.bmm(attn_weights.unsqueeze(0),
                                 encoder_outputs.unsqueeze(0))

        output = torch.cat((embedded[0], attn_applied[0]), 1)
        output = self.attn_combine(output).unsqueeze(0)

        output = torch.tanh(output)
        output, hidden = self.gru(output, hidden)

        output = F.log_softmax(self.out(output[0]), dim=1)
        return output, hidden, attn_weights

    def initHidden(self):
        return torch.zeros(1, 1, self.hidden_size, device=device)


def train_start(encoder, decoder, eng_word_vec_list, chi_word_vec_list, chi_word_index_list, vector_len, model_chi,
                eng_val_word_vec_list, chi_val_word_vec_list, chi_val_word_index_list, learning_rate=0.01,
                print_every=100, plot_every=100):
    plot_losses = []
    print_loss_total = 0
    plot_loss_total = 0
    encoder_optimizer = optim.SGD(encoder.parameters(), lr=learning_rate)  # 设置优化器
    decoder_optimizer = optim.SGD(decoder.parameters(), lr=learning_rate)

    action = input('是否需要加载checkpoint?  1 是 0 否 :   ')
    if action == '1':
        load_checkpoint(encoder1, attn_decoder1, encoder_optimizer, decoder_optimizer)
        new_epoch = input('需要再训练多少代，也可以输入0直接进行测试')
        global epoch_num
        epoch_num = int(new_epoch)

    criterion = nn.NLLLoss()  # 设置损失函数
    max_length = vector_len
    total_length = len(eng_word_vec_list)
    for epoch in range(epoch_num):  # 训练开始
        for index in range(total_length):  # 依次读出每一句的数据
            input_tensor = eng_word_vec_list[index]
            target_tensor = chi_word_vec_list[index]
            target_index = chi_word_index_list[index]
            if len(input_tensor) == 0 or len(target_tensor) == 0:
                continue

            loss = train(input_tensor, target_tensor, encoder,
                         decoder, encoder_optimizer, decoder_optimizer, criterion, max_length, target_index, model_chi)
            print_loss_total += loss  # 计算损失值，用于打印
            plot_loss_total += loss  # 计算损失值，用于最后的画图

            if (index % print_every == 0) and index > 10:  # 每print_every 次打印一次
                print_loss_avg = print_loss_total / print_every
                print_loss_total = 0
                print(f'epoch {epoch},{index},{index * 100 / total_length}%,loss:{print_loss_avg}')

            if (index % plot_every == 0) and index > 10:  # 每plot_every次，保存一下当前的平均损失
                plot_loss_avg = plot_loss_total / plot_every
                plot_losses.append(plot_loss_avg)
                plot_loss_total = 0
        # 每个epoch训练完成后进行验证
        bleu_score = 0
        val_length = len(eng_val_word_vec_list)
        for index in range(val_length):
            input_tensor = eng_val_word_vec_list[index]
            target_tensor = chi_val_word_vec_list[index]
            if len(input_tensor) == 0 or len(target_tensor) == 0:
                continue
            bleu = val(input_tensor, target_tensor, encoder,
                       decoder, max_length, model_chi, chi_val_word_index_list[index])
            bleu_score += bleu
        print(f'epoch {epoch},bleu is {bleu_score / val_length}')  # 打印对应的平均bleu
        save_checkpoint(encoder, decoder, encoder_optimizer, decoder_optimizer, epoch)
    showPlot(plot_losses)  # 画损失值的图


def showPlot(points):
    plt.plot(points)
    plt.show()


def train(input_tensor, target_tensor, encoder, decoder, encoder_optimizer, decoder_optimizer, criterion, max_length,
          target_index, model_chi):

    encoder_hidden = encoder.initHidden()  # 初始化隐藏状态

    encoder_optimizer.zero_grad()  # 梯度清零
    decoder_optimizer.zero_grad()

    input_length = len(input_tensor)
    target_length = len(target_index)

    encoder_outputs = torch.zeros(max_length, encoder.hidden_size, device=device)  # 初始化编码器第一个输入值

    loss = 0

    for ei in range(input_length):  # input tensor的值依次输入编码器，获取每个时刻输出，隐藏值
        encoder_output, encoder_hidden = encoder(
            input_tensor[ei], encoder_hidden)
        if encoder_output.ndim == 3:
            encoder_outputs[ei] = encoder_output[0, 0]

    # word=model_chi.wv.index_to_key[0]
    # decoder_input=torch.tensor(model_chi.wv[word])
    # decoder_input=decoder_input.view(1, 1, -1)
    # decoder_input=input_tensor[0]
    decoder_input = torch.zeros(1, 1, encoder_hidden.shape[2], device=device)  # 初始化解码器的初始输入值
    decoder_hidden = encoder_hidden  # 利用编码器的最后的输出的隐藏状态作为解码器的初始隐藏状态
    global teacher_forcing_ratio
    use_teacher_forcing = True if random.random() < teacher_forcing_ratio else False  # teacher forcing 选择
    if use_teacher_forcing:
        # Teacher forcing: Feed the target as the next input
        for di in range(target_length):  # 训练解码器
            decoder_output, decoder_hidden, decoder_attention = decoder(
                decoder_input, decoder_hidden, encoder_outputs)
            topv, topi = decoder_output.topk(1)
            decoder_input = topi.squeeze().detach()  # detach from history as input
            # word_pre = model_chi.wv.index_to_key[decoder_input]
            # word_real = model_chi.wv.index_to_key[target_index[di]]
            loss += criterion(decoder_output, target_index[di].to(device))  # 计算每个单词预测的损失值
            decoder_input = target_tensor[di].to(device)  # Teacher forcing，利用真实值作为下一个步长的输入
            decoder_input = decoder_input.to(torch.float32)  # 数据类型转换32位，不然可能会报错
    else:
        # Without teacher forcing: use its own predictions as the next input
        for di in range(target_length):
            decoder_output, decoder_hidden, decoder_attention = decoder(
                decoder_input, decoder_hidden, encoder_outputs)
            topv, topi = decoder_output.topk(1)
            decoder_input = topi.squeeze().detach()  # detach from history as input
            word = model_chi.wv.index_to_key[decoder_input]
            decoder_input = torch.tensor(model_chi.wv[word])  # 将预测的word的对应的向量作为下一个步长的输入
            decoder_input = decoder_input.view(1, 1, -1)  # 变为3维，不然会报错
            decoder_input = decoder_input.to(device)
            loss += criterion(decoder_output, target_index[di].to(device))  # 计算此次预测的损失

    loss.backward()  # 反向传播

    encoder_optimizer.step()  # 每一句训练完成后根据损失值更新模型参数
    decoder_optimizer.step()  # 每一句训练完成后根据损失值更新模型参数

    return loss.item() / target_length  # 返回当前句预测的损失值的平均值


def val(input_tensor, target_tensor, encoder, decoder, max_length, model_chi, target_index):
    encoder_hidden = encoder.initHidden()
    input_length = len(input_tensor)
    encoder_outputs = torch.zeros(max_length, encoder.hidden_size, device=device)
    for ei in range(input_length):
        encoder_output, encoder_hidden = encoder(
            input_tensor[ei], encoder_hidden)
        encoder_outputs[ei] = encoder_output[0, 0]
    y_true = []
    y_pred = []
    # word=model_chi.wv.index_to_key[0]
    # decoder_input=torch.tensor(model_chi.wv[word])
    # decoder_input=decoder_input.view(1, 1, -1)
    # decoder_input=input_tensor[0]
    decoder_input = torch.zeros(1, 1, encoder_hidden.shape[2], device=device)
    decoder_hidden = encoder_hidden
    target_length = len(target_tensor)
    for di in range(target_length):
        decoder_output, decoder_hidden, decoder_attention = decoder(
            decoder_input, decoder_hidden, encoder_outputs)
        topv, topi = decoder_output.topk(1)
        decoder_input = topi.squeeze().detach()  # detach from history as input
        word_pre = model_chi.wv.index_to_key[decoder_input]  # 获取预测的单词
        word_real = model_chi.wv.index_to_key[target_index[di]]  # 真实的单词

        decoder_input = torch.tensor(model_chi.wv[word_pre])  # 将预测的单词对应的向量作为下一个步长的解码器的输入
        decoder_input = decoder_input.view(1, 1, -1)
        decoder_input = decoder_input.to(device)
        y_pred.append(word_pre)  # 保存预测单词
        y_true.append(word_real)  # 保存真实单词
    BLEUscore = nltk.translate.bleu_score.corpus_bleu([y_true], [y_pred],
                                                      weights=[1])  # 利用nltk计算bleu，nltk 计算bleu时，默认时bleu=4
    return BLEUscore


def test_start(encoder, decoder, max_length):
    # 读取测试数据
    # 读取英文测试数据
    eng_test_file = 'test_en.txt'
    chi_test_file = 'test_ch.txt'
    fn = open(eng_test_file, 'r', encoding='UTF-8')  # 打开文件
    eng_string_lines = fn.readlines()  # 读出整个文件
    fn.close()
    print(len(eng_string_lines))  # 读取英文的行总数
    eng_string_lines = [line.lower() for line in eng_string_lines]  # 全部转为小写
    eng_test_word_list = []

    for line in eng_string_lines:
        line_no_punct = remove_punctuation(line)
        seg_list = nltk.word_tokenize(line_no_punct)  # 进行分词
        list_temp = []
        for temp_term in seg_list:
            if temp_term not in eng_words_with_low_fre:  # 如果不是低频词
                list_temp.append(temp_term)
        eng_test_word_list.append(list_temp)

    eng_test_word_vec_list = []
    for sentence in eng_test_word_list:
        sentence_vec_list = []
        for word in sentence:  # 将每个词的向量加入矩阵
            word_vec = np.zeros(word_vector_size)
            if word in model_eng.wv.key_to_index:
                word_vec = torch.tensor(model_eng.wv[word])
                word_vec = word_vec.view(1, 1, -1)
                sentence_vec_list.append(word_vec)
        eng_test_word_vec_list.append(sentence_vec_list)

    # 读取中文验证数据
    fn = open(chi_test_file, 'r', encoding='UTF-8')  # 打开文件
    chi_string_lines = fn.readlines()  # 读出整个文件
    fn.close()
    chinese_test_word_list = []
    for line in chi_string_lines:
        line = line.strip()  # 去掉空格和换行符号
        line_no_punct = re.sub("[{}]+".format(punctuation), '', line)  # 去掉标点符号
        seg_list = list(jieba.cut(line_no_punct))  # 利用jieba分词
        list_temp = []
        for temp_term in seg_list:
            if temp_term not in chi_words_with_low_fre:  # 如果不是低频词
                list_temp.append(temp_term)
        chinese_test_word_list.append(list_temp)

    chi_test_word_vec_list = []
    chi_test_word_index_list = []
    for sentence in chinese_test_word_list:
        sentence_vec_list = []
        sentence_index_list = []
        for word in sentence:  # 将每个词的向量加入矩阵
            word_vec = np.zeros(word_vector_size)
            if word in model_chi.wv.key_to_index:
                word_vec = torch.tensor(model_chi.wv[word])
                word_vec = word_vec.view(1, 1, -1)
                sentence_vec_list.append(word_vec)
                index = torch.tensor(model_chi.wv.key_to_index[word])
                index = index.view(1)
                sentence_index_list.append(index)
        chi_test_word_vec_list.append(sentence_vec_list)
        chi_test_word_index_list.append(sentence_index_list)

    # 开始利用测试数据进行预测
    bleu_score = 0
    test_length = len(eng_test_word_vec_list)
    for index in range(test_length):
        input_tensor = eng_test_word_vec_list[index]
        target_tensor = chi_test_word_vec_list[index]
        target_index = chi_test_word_index_list[index]
        if len(input_tensor) == 0 or len(target_tensor) == 0:
            continue
        encoder_hidden = encoder.initHidden()
        input_length = len(input_tensor)
        encoder_outputs = torch.zeros(max_length, encoder.hidden_size, device=device)
        for ei in range(input_length):
            encoder_output, encoder_hidden = encoder(
                input_tensor[ei], encoder_hidden)
            encoder_outputs[ei] = encoder_output[0, 0]
        y_true = []
        y_pred = []

        decoder_input = torch.zeros(1, 1, encoder_hidden.shape[2], device=device)
        decoder_hidden = encoder_hidden
        target_length = len(target_tensor)
        for di in range(target_length):
            decoder_output, decoder_hidden, decoder_attention = decoder(
                decoder_input, decoder_hidden, encoder_outputs)
            topv, topi = decoder_output.topk(1)
            decoder_input = topi.squeeze().detach()  # detach from history as input
            word_pre = model_chi.wv.index_to_key[decoder_input]
            word_real = model_chi.wv.index_to_key[target_index[di]]

            decoder_input = torch.tensor(model_chi.wv[word_pre])
            decoder_input = decoder_input.view(1, 1, -1)
            decoder_input = decoder_input.to(device)
            y_pred.append(word_pre)
            y_true.append(word_real)
        BLEUscore = nltk.translate.bleu_score.corpus_bleu([y_true], [y_pred], weights=[1])
        bleu_score += BLEUscore
    print(f'测试数据 bleu_score 值为 {bleu_score / test_length} ')


# 保存模型
def save_checkpoint(encoder, decoder, encoder_optimizer, decoder_optimizer, epoch):
    print('save check_point')
    checkpoint_encoder = {'state_dict': encoder.state_dict(), 'optimizer': encoder_optimizer.state_dict(),
                          'epoch': epoch}
    torch.save(checkpoint_encoder, 'seq2seq_encoder.pth')
    checkpoint_decoder = {'state_dict': decoder.state_dict(), 'optimizer': decoder_optimizer.state_dict(),
                          'epoch': epoch}
    torch.save(checkpoint_decoder, 'seq2seq_decoder.pth')


# 加载模型
def load_checkpoint(encoder, decoder, encoder_optimizer, decoder_optimizer):
    if os.path.exists('seq2seq_encoder.pth') and os.path.exists('seq2seq_decoder.pth'):
        print('Load checkpoint')
    else:
        print('no model save')
        return
    encoder_checkpoint = torch.load('seq2seq_encoder.pth')
    encoder_epoch = encoder_checkpoint['epoch']
    print(f'encoder 训练了{encoder_epoch + 1}个epoch')
    encoder.load_state_dict(encoder_checkpoint['state_dict'])
    encoder_optimizer.load_state_dict(encoder_checkpoint['optimizer'])

    decoder_checkpoint = torch.load('seq2seq_decoder.pth')
    decoder_epoch = decoder_checkpoint['epoch']
    print(f'decoder 训练了{decoder_epoch + 1}个epoch')
    decoder.load_state_dict(decoder_checkpoint['state_dict'])
    decoder_optimizer.load_state_dict(decoder_checkpoint['optimizer'])


if __name__ == '__main__':  # 程序入口
    vector_len = 80  # 设置最大长度
    word_vector_size = 100  # 设置词向量化后的维度
    data.path.append(r"d:\nltk_data")
    low_fre_num = 4  # 出现次数低于2次的认为是低频词，会过滤掉
    eng_train_file = 'train_en.txt'
    chi_train_file = 'train_ch.txt'
    eng_val_file = 'val_en.txt'
    chi_val_file = 'val_ch.txt'
    # 英文 word2vec
    fn = open(eng_train_file, 'r', encoding='UTF-8')  # 打开文件
    eng_string_data = fn.read()  # 读出整个文件
    fn.close()  # 关闭文件
    eng_string_data = eng_string_data.lower()  # 全部转为小写
    eng_string_data_no_punct = remove_punctuation(eng_string_data)  # 去掉标点符号
    eng_words = nltk.word_tokenize(eng_string_data_no_punct)  # 利用nltk对英文字符串进行分词
    eng_words_freq = nltk.FreqDist(eng_words)  # 计算分词后的词频
    eng_words_with_low_fre = []
    for k, v in eng_words_freq.items():
        if v < low_fre_num:
            eng_words_with_low_fre.append(k)  # 将低词频的词加入低词频list，用于后续进行低词频词过滤
    print(eng_words_with_low_fre)  # 打印低频词对应的list

    fn = open(eng_train_file, 'r', encoding='UTF-8')  # 打开文件
    eng_string_lines = fn.readlines()  # 读出整个文件
    fn.close()
    print(len(eng_string_lines))  # 读取英文的行总数
    eng_string_lines = [line.lower() for line in eng_string_lines]  # 全部转为小写
    eng_word_list = []

    for line in eng_string_lines:
        line_no_punct = remove_punctuation(line)
        seg_list = nltk.word_tokenize(line_no_punct)  # 进行分词
        list_temp = []
        for temp_term in seg_list:
            if temp_term not in eng_words_with_low_fre:  # 如果不是低频词，则加入到list里，如果是就抛弃不管
                list_temp.append(temp_term)
        eng_word_list.append(list_temp)
    model_eng = Word2Vec(eng_word_list, sg=0, vector_size=word_vector_size, window=5, min_count=5,
                         workers=5)  # 通过预处理模型word2vec进行英文词的向量化
    print(model_eng.wv.key_to_index)  # 打印词和对应的index

    # 中文 word2vec

    fn = open(chi_train_file, 'r', encoding='UTF-8')  # 打开文件
    chi_string_data = fn.read()  # 读出整个文件
    fn.close()  # 关闭文件
    punctuation = r"~ ,，！？｡。.＂＃＄％＆＇（）\\ ＊＋－／：；＜＝＞＠［＼］＾＿｀｛｜｝～｟｠｢｣､、〃》「」『』【】〔〕〖〗〘〙〚〛〜〝〞〟〰〾〿–—‘'‛“”„‟…‧﹏"
    chi_string_data_no_punct = re.sub("[{}]+".format(punctuation), '', chi_string_data)  # 去掉标点符号
    chi_words = jieba.cut(chi_string_data_no_punct, cut_all=False, HMM=True)  # 精确模式分词+HMM
    chi_word_freq = collections.Counter(chi_words)  # 统计中文的词频
    print(chi_word_freq.items())  # 打印词频信息
    chi_words_with_low_fre = []
    for k, v in chi_word_freq.items():
        if v < low_fre_num:
            chi_words_with_low_fre.append(k)  # 统计低词频的词，建立list，为后续过滤准备
    print(chi_words_with_low_fre)  # 获取低频词对应的list

    fn = open(chi_train_file, 'r', encoding='UTF-8')  # 打开文件
    chi_string_lines = fn.readlines()  # 读出整个文件
    fn.close()  # 关闭文件
    print(len(chi_string_lines))

    # 使用正则表达式匹配中文句号、感叹号、问号等标点符号
    chinese_word_list = []
    for line in chi_string_lines:
        line = line.strip()  # 去掉空格和换行符号
        line_no_punct = re.sub("[{}]+".format(punctuation), '', line)  # 去掉标点符号
        seg_list = list(jieba.cut(line_no_punct))  # 利用jieba分词
        list_temp = []
        for temp_term in seg_list:
            if temp_term not in chi_words_with_low_fre:  # 如果不是低频词，则加入到lis里，如果是就抛弃不管
                list_temp.append(temp_term)
        chinese_word_list.append(list_temp)
        # chinese_word_list.append(seg_list)

    model_chi = Word2Vec(chinese_word_list, sg=0, vector_size=word_vector_size, window=5, min_count=5,
                         workers=5)  # 通过预处理模型word2vec进行中文词的向量化
    print(model_chi.wv.key_to_index)
    print('中文语料集index 10为', chinese_word_list[10])
    print('英语语料集index 10为', eng_word_list[10])

    eng_word_vec_list = []
    for sentence in eng_word_list:  # 依次读出英文每一句的分词后的list,然后将每个list里面的每个词转为对应的向量化矩阵
        sentence_vec_list = []
        for word in sentence:
            word_vec = np.zeros(word_vector_size)
            if word in model_eng.wv.key_to_index:
                word_vec = torch.tensor(model_eng.wv[word])
                word_vec = word_vec.view(1, 1, -1)
                sentence_vec_list.append(word_vec)  # 保存每个词的向量
        eng_word_vec_list.append(sentence_vec_list)  # 将存有向量的每一句存入一个总的List里
    print(eng_word_vec_list)

    chi_word_vec_list = []
    chi_word_index_list = []
    for sentence in chinese_word_list:
        sentence_vec_list = []
        sentence_index_list = []
        for word in sentence:  # 依次读出英文每一句的分词后的list,然后将每个list里面的每个词转为对应的向量化矩阵，同时获取每一个词对应的index，用于后续的模型训练、预测等
            word_vec = np.zeros(word_vector_size)
            if word in model_chi.wv.key_to_index:
                word_vec = torch.tensor(model_chi.wv[word])
                word_vec = word_vec.view(1, 1, -1)
                sentence_vec_list.append(word_vec)  # 保存每个词的向量
                index = torch.tensor(model_chi.wv.key_to_index[word])
                index = index.view(1)
                sentence_index_list.append(index)  # 保存每个词的index
        chi_word_vec_list.append(sentence_vec_list)  # 将存有向量的每一句存入一个总的List里
        chi_word_index_list.append(sentence_index_list)  # 将存有index的每一句存入一个总的List里
    print(chi_word_vec_list)
    print(len(model_chi.wv.key_to_index))

    # 读取验证数据,验证数据处理和训练数据类似
    # 读取英文验证数据
    fn = open(eng_val_file, 'r', encoding='UTF-8')  # 打开文件
    eng_string_lines = fn.readlines()  # 读出整个文件
    fn.close()
    print(len(eng_string_lines))  # 读取英文的行总数
    eng_string_lines = [line.lower() for line in eng_string_lines]  # 全部转为小写
    eng_val_word_list = []

    for line in eng_string_lines:
        line_no_punct = remove_punctuation(line)
        seg_list = nltk.word_tokenize(line_no_punct)  # 进行分词
        list_temp = []
        for temp_term in seg_list:
            if temp_term not in eng_words_with_low_fre:  # 如果不是低频词
                list_temp.append(temp_term)
        eng_val_word_list.append(list_temp)

    eng_val_word_vec_list = []
    for sentence in eng_val_word_list:
        sentence_vec_list = []
        for word in sentence:  # 将每个词的向量加入矩阵
            word_vec = np.zeros(word_vector_size)
            if word in model_eng.wv.key_to_index:
                word_vec = torch.tensor(model_eng.wv[word])
                word_vec = word_vec.view(1, 1, -1)
                sentence_vec_list.append(word_vec)
        eng_val_word_vec_list.append(sentence_vec_list)

    # 读取中文验证数据
    fn = open(chi_val_file, 'r', encoding='UTF-8')  # 打开文件
    chi_string_lines = fn.readlines()  # 读出整个文件
    fn.close()
    chinese_val_word_list = []
    for line in chi_string_lines:
        line = line.strip()  # 去掉空格和换行符号
        line_no_punct = re.sub("[{}]+".format(punctuation), '', line)  # 去掉标点符号
        seg_list = list(jieba.cut(line_no_punct))  # 利用jieba分词
        list_temp = []
        for temp_term in seg_list:
            if temp_term not in chi_words_with_low_fre:  # 如果不是低频词
                list_temp.append(temp_term)
        chinese_val_word_list.append(list_temp)

    chi_val_word_vec_list = []
    chi_val_word_index_list = []
    for sentence in chinese_val_word_list:
        sentence_vec_list = []
        sentence_index_list = []
        for word in sentence:  # 将每个词的向量加入矩阵
            word_vec = np.zeros(word_vector_size)
            if word in model_chi.wv.key_to_index:
                word_vec = torch.tensor(model_chi.wv[word])
                word_vec = word_vec.view(1, 1, -1)
                sentence_vec_list.append(word_vec)
                index = torch.tensor(model_chi.wv.key_to_index[word])
                index = index.view(1)
                sentence_index_list.append(index)
        chi_val_word_vec_list.append(sentence_vec_list)
        chi_val_word_index_list.append(sentence_index_list)

    encoder1 = EncoderRNN(word_vector_size).to(device)  # 实例化编码器
    attn_decoder1 = AttnDecoderRNN(word_vector_size, len(model_chi.wv.key_to_index), vector_len, dropout_p=0.2).to(
        device)  # 实例化解码器
    encoder1.to(device)  # 利用gpu加速
    attn_decoder1.to(device)  # 利用gpu加速
    train_start(encoder1, attn_decoder1, eng_word_vec_list, chi_word_vec_list, chi_word_index_list, vector_len,
                model_chi, eng_val_word_vec_list, chi_val_word_vec_list, chi_val_word_index_list)
    test_start(encoder1, attn_decoder1, vector_len)
